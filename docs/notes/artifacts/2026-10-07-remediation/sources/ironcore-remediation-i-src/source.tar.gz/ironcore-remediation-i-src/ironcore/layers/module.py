# Copyright (c) 2025-2026 Jaegeun Han
#
# SPDX-License-Identifier: Apache-2.0

import math
import zlib

import torch
from torch.cuda import nvtx
from torch.profiler import record_function

from ironcore.config import MainConfig


class BaseModule(torch.nn.Module):
    """
    class BaseModule
    """

    def __init__(self, config: MainConfig):

        super().__init__()

        self.config = config

        self.init_std = self.config.init.init_std
        self.xavier_init = self.config.init.xavier_init
        self.use_reentrant = (
            True if self.config.operation.recompute_strategy == "optimized" else False
        )

        # profier
        self._record_function = None  # for pytorch profiler
        self._nvtx_range = None
        self._hooks_registered = False
        self._torch_profiler = False
        self._gpu_profiler = False
        self._layer_timing = False
        self._timing_collector = None

    def init_weights(self):
        """Initialize model weights with proper handling for tensor parallel layers."""
        for name, param in self.named_parameters():
            if "bias" in name:
                # zero initialization to bias
                torch.nn.init.zeros_(param)
                continue

            if "norm" in name:
                # layer norm scale parameter initialization
                torch.nn.init.ones_(param)
                continue

            # Check if this parameter belongs to a tensor parallel layer
            # We need to initialize the full tensor and then extract the shard
            module = self._get_module_for_param(name)
            is_tp_layer = (
                hasattr(module, "column_parallel") or hasattr(module, "row_parallel")
            ) and name.endswith("weight")

            if is_tp_layer:
                # Keep TP=1 and TP>1 on the same deterministic initialization path.
                self._init_tp_weight(name, param, module)
            else:
                # Non-TP layer: initialize directly
                if self.xavier_init:
                    torch.nn.init.xavier_uniform_(param)
                else:
                    torch.nn.init.normal_(param, std=self.init_std, mean=0.0)

                # following nanoGPT's trick
                # apply special scaled init to the residual projections, per GPT-2 paper
                if name.endswith("output.weight") or name.endswith("down_proj.weight"):
                    torch.nn.init.normal_(
                        param,
                        std=self.init_std / math.sqrt(2 * self.config.model.num_layers),
                        mean=0.0,
                    )

    def _get_module_for_param(self, param_name):
        """Get the module that owns a given parameter."""
        parts = param_name.split(".")
        module = self
        for part in parts[:-1]:  # Exclude the last part (parameter name)
            if part.isdigit():
                module = module[int(part)]
            else:
                module = getattr(module, part)
        return module

    def _init_tp_weight(self, name, param, module):
        """Initialize weights for tensor parallel layers by creating full tensor and extracting shard."""
        from ironcore.parallel import parallel_states

        tp_rank = parallel_states.get_tensor_model_parallel_rank()
        tp_size = parallel_states.get_tensor_model_parallel_world_size()

        # Determine full shape and shard dimension based on parallelism type
        if hasattr(module, "column_parallel") and module.column_parallel:
            # ColumnParallelLinear: shard along dim=1 (columns)
            # Current param shape: [input_size, output_size // tp_size]
            # Full shape: [input_size, output_size]
            # Note: concatenated_weights is already accounted for in the output_size before division
            full_shape = (param.shape[0], param.shape[1] * tp_size)
            shard_dim = 1
        elif hasattr(module, "row_parallel") and module.row_parallel:
            # RowParallelLinear or VocabParallelEmbedding: shard along dim=0 (rows)
            # Current param shape: [input_size // tp_size, output_size]
            # Full shape: [input_size, output_size]
            full_shape = (param.shape[0] * tp_size, param.shape[1])
            shard_dim = 0
        else:
            # Fallback: initialize directly
            torch.nn.init.normal_(param, std=self.init_std, mean=0.0)
            return

        # Stable per-parameter seeds prevent equal-shaped layers from receiving
        # identical values. A local generator leaves process RNG state untouched.
        seed = (self.config.init.seed + zlib.crc32(name.encode("utf-8"))) % (2**63)
        generator = torch.Generator(device=param.device)
        generator.manual_seed(seed)

        full_tensor = torch.empty(full_shape, dtype=param.dtype, device=param.device)

        # Determine initialization std (special case for residual projections)
        init_std = self.init_std
        if name.endswith("output.weight") or name.endswith("down_proj.weight"):
            init_std = self.init_std / math.sqrt(2 * self.config.model.num_layers)

        if self.xavier_init:
            torch.nn.init.xavier_uniform_(full_tensor, generator=generator)
        else:
            torch.nn.init.normal_(full_tensor, std=init_std, mean=0.0, generator=generator)

        # Extract the shard for this rank
        shard_size = param.shape[shard_dim]

        # Check for concatenated weights (only for ColumnParallelLinear)
        concatenated_weights = getattr(module, "concatenated_weights", 1)

        if shard_dim == 1 and concatenated_weights > 1:
            # Complex splitting for ColumnParallel with concatenation (e.g. QKV or KV)
            # full_tensor: [input, output_total]
            output_total = full_shape[1]
            per_part = output_total // concatenated_weights

            # Split into parts (e.g. K, V)
            parts = torch.split(full_tensor, per_part, dim=1)

            shards = []
            for part in parts:
                # Split part into TP shards
                part_shard_size = per_part // tp_size
                start = tp_rank * part_shard_size
                end = (tp_rank + 1) * part_shard_size
                shards.append(part[:, start:end])

            shard = torch.cat(shards, dim=1)
        else:
            start_idx = tp_rank * shard_size
            end_idx = (tp_rank + 1) * shard_size

            if shard_dim == 0:
                shard = full_tensor[start_idx:end_idx, :]
            else:  # shard_dim == 1
                shard = full_tensor[:, start_idx:end_idx]

        # Copy the shard to the parameter
        with torch.no_grad():
            param.copy_(shard)

    @property
    def device(self):
        try:
            return next(self.parameters()).device
        except StopIteration:
            try:
                return next(self.buffers()).device
            except StopIteration:
                # Default to cpu if no params or buffers
                return torch.device("cpu")

    @property
    def dtype(self):
        return next(self.parameters()).dtype

    def _forward_pre_hook(self, module, input):
        name = f"{self.__class__.__name__}"
        if self._torch_profiler:
            self._record_function = record_function(f"Forward {name}")
            self._record_function.__enter__()
        if self._gpu_profiler:
            self._nvtx_range = nvtx.range_push(f"Forward {name}")
        if self._layer_timing and self._timing_collector is not None:
            self._timing_collector.start(id(self), name, "forward")

    def _forward_post_hook(self, module, input, output):
        if self._record_function is not None:
            self._record_function.__exit__(None, None, None)
            self._record_function = None
        if self._nvtx_range is not None:
            nvtx.range_pop()
            self._nvtx_range = None
        if self._layer_timing and self._timing_collector is not None:
            self._timing_collector.end(id(self))

    def _backward_pre_hook(self, module, grad_output):
        name = f"{self.__class__.__name__}"
        if self._torch_profiler:
            self._record_function = record_function(f"Backward {name}")
            self._record_function.__enter__()
        if self._gpu_profiler:
            self._nvtx_range = nvtx.range_push(f"Backward {name}")
        if self._layer_timing and self._timing_collector is not None:
            self._timing_collector.start(id(self), name, "backward")

    def _backward_post_hook(self, module, grad_input, grad_output):
        if self._record_function is not None:
            self._record_function.__exit__(None, None, None)
            self._record_function = None
        if self._nvtx_range is not None:
            nvtx.range_pop()
            self._nvtx_range = None
        if self._layer_timing and self._timing_collector is not None:
            self._timing_collector.end(id(self))

    def register_profile_hooks(
        self,
        torch_profiler: bool = False,
        gpu_profiler: bool = False,
        layer_timing: bool = False,
    ):
        if self._hooks_registered:
            return
        self._torch_profiler = torch_profiler
        self._gpu_profiler = gpu_profiler
        self._layer_timing = layer_timing
        if layer_timing:
            from ironcore.profiler import get_layer_timing_collector

            self._timing_collector = get_layer_timing_collector()

        self.register_forward_pre_hook(self._forward_pre_hook)
        self.register_forward_hook(self._forward_post_hook)
        self.register_full_backward_pre_hook(self._backward_pre_hook)
        self.register_full_backward_hook(self._backward_post_hook)
        self._hooks_registered = True

        for module in self.modules():
            if module is not self and isinstance(module, BaseModule):
                module.register_profile_hooks(torch_profiler, gpu_profiler, layer_timing)
