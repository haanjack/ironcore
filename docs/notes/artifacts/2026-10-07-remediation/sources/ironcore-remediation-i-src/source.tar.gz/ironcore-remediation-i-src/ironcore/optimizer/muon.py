# Copyright (c) 2025-2026 Jaegeun Han
#
# SPDX-License-Identifier: Apache-2.0
"""
Muon Optimizer: MomentUm Orthogonalized by Newton-Schulz

Muon is an optimizer for 2D parameters of neural network hidden layers.
It uses Newton-Schulz iteration to orthogonalize the momentum update,
achieving better sample efficiency for transformer training.

Reference: https://kellerjordan.github.io/posts/muon/

Key features:
- Applies to 2D weight matrices of hidden layers only
- Uses Nesterov-style momentum (beta=0.95 empirically best)
- Newton-Schulz 5 iteration for efficient orthogonalization
- Hybrid approach: Muon for 2D hidden weights, AdamW for embeddings/output/biases
"""

import math

import torch
from torch.optim import Optimizer

from ironcore.offload.optimizer_helpers import _adamw_offloaded_step, _should_offload_param


def zeropower_via_newtonschulz5(
    grad: torch.Tensor, steps: int = 5, eps: float = 1e-7
) -> torch.Tensor:
    """
    Newton-Schulze iteration to approximate the orthogonalization of a matrix.

    This computes an approximation to argmin_O { ||O - grad||_F : O^T O = I or O O^T = I },
    which is equivalent to replacing grad with its nearest semi-orthogonal matrix.

    Args:
        grad: Input gradient matrix (2D tensor)
        steps: Number of Newton-Schulz iterations (default: 5)
        eps: Small constant for numerical stability

    Returns:
        Approximately orthogonalized matrix with same shape as grad

    Reference:
        Bernstein & Newhouse (2024); Higham (2008); Björck & Bowie (1971)
        Coefficients (a, b, c) are specifically tuned for 5th-order convergence.
    """
    assert grad.ndim == 2, f"Expected 2D tensor, got {grad.ndim}D"

    # Coefficients tuned for fast 5th-order convergence
    a, b, c = (3.4445, -4.7750, 2.0315)

    # Work in bfloat16 for efficiency
    x = grad.bfloat16()

    # Normalize to ensure singular values are in [0, 1]
    x = x / (x.norm() + eps)

    # Handle tall matrices by transposing
    transposed = False
    if grad.size(0) > grad.size(1):
        x = x.T
        transposed = True

    # Newton-Schulz iterations
    for _ in range(steps):
        a_mat = x @ x.T
        b_mat = b * a_mat + c * (a_mat @ a_mat)
        x = a * x + b_mat @ x

    # Undo transpose if needed
    if transposed:
        x = x.T

    return x


def _orthogonalize_tp_aware(
    grad_for_update: torch.Tensor, param: torch.Tensor, newton_schulz_steps: int
) -> tuple[torch.Tensor, tuple[int, ...]]:
    """
    Newton-Schulz orthogonalization for a (possibly tensor-parallel-sharded) 2D param.

    Orthogonalizing a local TP shard is mathematically different from orthogonalizing
    the full matrix, so under TP>1 this gathers the full matrix across the TP group,
    orthogonalizes it once, and re-shards the result back to this rank's local slice.
    This keeps the Muon update identical to what a TP=1 run would compute.

    Returns the (possibly re-sharded) update together with the shape of the matrix
    that was actually orthogonalized (full matrix under TP, local shard otherwise),
    since the RMS-matching scale must be computed from that shape to stay
    equivalent to the TP=1 case.
    """
    if not getattr(param, "is_tp_sharded", False):
        update = zeropower_via_newtonschulz5(grad_for_update, steps=newton_schulz_steps)
        return update, tuple(update.shape)

    from ironcore.parallel import parallel_states

    if parallel_states.get_tensor_model_parallel_world_size() == 1:
        update = zeropower_via_newtonschulz5(grad_for_update, steps=newton_schulz_steps)
        return update, tuple(update.shape)

    from ironcore.parallel.tensor_parallel.comm import (
        _gather_concated_tensor_along_last_dim,
        _gather_tensor_along_first_dim,
        _gather_tensor_along_last_dim,
        _split_concated_tensor_along_last_dim,
        _split_tensor_along_first_dim,
        _split_tensor_along_last_dim,
    )

    shard_dim = getattr(param, "tp_shard_dim", None)
    concatenated = getattr(param, "tp_concatenated_weights", 1)

    if shard_dim == 1:
        full = (
            _gather_concated_tensor_along_last_dim(grad_for_update, concatenated)
            if concatenated > 1
            else _gather_tensor_along_last_dim(grad_for_update)
        )
    elif shard_dim == 0:
        full = _gather_tensor_along_first_dim(grad_for_update)
    else:
        # Shard-dim metadata missing: fall back to local-shard orthogonalization
        # rather than risk gathering along the wrong axis.
        update = zeropower_via_newtonschulz5(grad_for_update, steps=newton_schulz_steps)
        return update, tuple(update.shape)

    full_shape = tuple(full.shape)
    orthogonal_full = zeropower_via_newtonschulz5(full, steps=newton_schulz_steps)

    if shard_dim == 1:
        resharded = (
            _split_concated_tensor_along_last_dim(orthogonal_full, concatenated)
            if concatenated > 1
            else _split_tensor_along_last_dim(orthogonal_full)
        )
    else:
        resharded = _split_tensor_along_first_dim(orthogonal_full)

    return resharded, full_shape


class MuonOptimizer(Optimizer):
    """
    Muon optimizer for 2D parameters with Newton-Schulz orthogonalization.

    Muon (MomentUm Orthogonalized by Newton-Schulz) optimizes 2D neural network
    parameters by taking the updates generated by SGD-momentum, and then applying
    a Newton-Schulz iteration as a post-processing step to orthogonalize them.

    This is a hybrid optimizer that:
    - Uses Muon for 2D hidden layer weights (attention projections, MLP weights)
    - Uses AdamW for non-2D params, embeddings, output layers, biases, norms

    Args:
        muon_params: Parameters to optimize with Muon (list of dicts with 'params' key)
        adamw_params: Parameters to optimize with AdamW (list of dicts with 'params' key)
        lr: Learning rate for Muon (default: 0.02, typically 2-5x higher than AdamW)
        momentum: Nesterov momentum beta for Muon (default: 0.95)
        newton_schulz_steps: Number of Newton-Schulz iterations (default: 5)
        weight_decay: Weight decay coefficient (default: 0.0)
        nesterov: Whether to use Nesterov momentum (default: True)
        adamw_lr: Learning rate for AdamW params (default: same as lr)
        adamw_betas: Betas for AdamW (default: (0.9, 0.95))
        adamw_eps: Epsilon for AdamW (default: 1e-8)
        adamw_weight_decay: Weight decay for AdamW (default: 0.01)

    Example:
        >>> optimizer = MuonOptimizer(
        ...     muon_params=[{"params": muon_weights, "weight_decay": 0.01}],
        ...     adamw_params=[{"params": other_params, "weight_decay": 0.01}],
        ...     lr=0.02,
        ...     momentum=0.95,
        ... )
    """

    def __init__(
        self,
        muon_params: list[dict],
        adamw_params: list[dict],
        lr: float = 0.02,
        momentum: float = 0.95,
        newton_schulz_steps: int = 5,
        weight_decay: float = 0.0,
        nesterov: bool = True,
        # AdamW settings for non-Muon params
        adamw_lr: float | None = None,
        adamw_betas: tuple = (0.9, 0.95),
        adamw_eps: float = 1e-8,
        adamw_weight_decay: float = 0.01,
        # Offload settings
        offload_enabled: bool = False,
        offload_min_param_elements: int = 65536,
        optimizer_state_precision: str = "fp32",
    ):
        # Store Muon-specific settings
        self.momentum = momentum
        self.newton_schulz_steps = newton_schulz_steps
        self.nesterov = nesterov
        self.adamw_lr = adamw_lr if adamw_lr is not None else lr
        self.offload_enabled = offload_enabled
        self.offload_min_param_elements = offload_min_param_elements
        self.state_dtype = {"fp32": torch.float32, "fp16": torch.float16, "bf16": torch.bfloat16}[
            optimizer_state_precision
        ]

        # Build param groups list following standard torch.optim.Optimizer pattern
        param_groups = []

        # Muon param groups
        for group in muon_params:
            param_group = {
                "params": group["params"],
                "lr": lr,
                "weight_decay": weight_decay,
                "optimizer_type": "muon",
            }
            param_group.update({k: v for k, v in group.items() if k != "params"})
            param_groups.append(param_group)

        # AdamW param groups
        for group in adamw_params:
            param_group = {
                "params": group["params"],
                "lr": self.adamw_lr,
                "betas": adamw_betas,
                "eps": adamw_eps,
                "weight_decay": group.get("weight_decay", adamw_weight_decay),
                "optimizer_type": "adamw",
                "amsgrad": False,
            }
            param_group.update({k: v for k, v in group.items() if k != "params"})
            param_groups.append(param_group)

        super().__init__(param_groups, {})

    @torch.no_grad()
    def step(self, closure=None):
        """
        Performs a single optimization step.

        For Muon parameters:
        1. Update momentum buffer with Nesterov-style update
        2. Apply Newton-Schulz orthogonalization
        3. Apply weight decay (decoupled)
        4. Update parameters

        For AdamW parameters:
        Standard AdamW update with bias correction.
        """
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            optimizer_type = group.get("optimizer_type", "muon")

            if optimizer_type == "muon":
                self._step_muon(group)
            else:
                self._step_adamw(group)

        return loss

    def _step_muon(self, group):
        """Apply Muon update to a parameter group."""
        lr = group["lr"]
        weight_decay = group["weight_decay"]
        momentum = self.momentum
        nesterov = self.nesterov

        for p in group["params"]:
            if p.grad is None:
                continue

            grad = p.grad

            # Only apply Muon to 2D parameters
            if grad.dim() != 2:
                # Fall back to SGD for non-2D params
                self._step_sgd_fallback(p, grad, group)
                continue

            state = self.state[p]

            # State initialization
            if len(state) == 0:
                state["step"] = 0
                # Momentum buffer
                state["momentum_buffer"] = torch.zeros_like(p, dtype=self.state_dtype)

            state["step"] += 1
            momentum_buffer = state["momentum_buffer"]

            # Update momentum buffer FIRST (correct Nesterov order)
            # momentum_buffer = beta * momentum_buffer + (1 - beta) * grad
            one_minus_beta = 1.0 - momentum
            momentum_buffer.mul_(momentum).add_(grad, alpha=one_minus_beta)

            # Compute Nesterov look-ahead using UPDATED buffer
            if nesterov:
                # Nesterov: grad_for_update = beta * momentum_buffer + (1 - beta) * grad
                # This is equivalent to grad.lerp(momentum_buffer, momentum) but dtype-safe
                grad_for_update = momentum * momentum_buffer + one_minus_beta * grad
            else:
                grad_for_update = momentum_buffer.clone()

            # Apply Newton-Schulz orthogonalization (TP-aware: gathers the full
            # matrix across the TP group first when p is a TP-sharded weight)
            orthogonal_update, orthogonalized_shape = _orthogonalize_tp_aware(
                grad_for_update, p, self.newton_schulz_steps
            )

            # Apply scaling to match AdamW's update RMS (~0.2-0.4)
            # Reference: Moonshot AI paper (arxiv:2502.16982), Equation 4
            # Muon's theoretical update RMS is sqrt(1/max(A,B))
            # We scale by 0.2 * sqrt(max(A,B)) to match AdamW's RMS
            # Note: scaling must use the shape that was actually orthogonalized
            # (the full matrix under TP, not the local shard) to match TP=1.
            rows, cols = orthogonalized_shape
            update_rms_scaling = 0.2 * (max(rows, cols) ** 0.5)
            orthogonal_update.mul_(update_rms_scaling)

            # Scale by learning rate
            update = lr * orthogonal_update

            # Apply decoupled weight decay
            if weight_decay != 0:
                p.mul_(1 - lr * weight_decay)

            # Apply update
            p.sub_(update)

    def _step_sgd_fallback(self, p, grad, group):
        """Fallback SGD update for non-2D parameters in Muon groups."""
        lr = group["lr"]
        weight_decay = group["weight_decay"]
        momentum = self.momentum

        state = self.state[p]

        if len(state) == 0:
            state["step"] = 0
            state["momentum_buffer"] = torch.zeros_like(p, dtype=self.state_dtype)

        state["step"] += 1
        momentum_buffer = state["momentum_buffer"]

        # Standard SGD with momentum
        momentum_buffer.mul_(momentum).add_(grad)

        if weight_decay != 0:
            p.mul_(1 - lr * weight_decay)

        p.sub_(lr * momentum_buffer)

    def _step_adamw(self, group):
        """Apply AdamW update to a parameter group."""
        lr = group["lr"]
        beta1, beta2 = group["betas"]
        eps = group["eps"]
        weight_decay = group["weight_decay"]
        amsgrad = group.get("amsgrad", False)

        for p in group["params"]:
            if p.grad is None:
                continue

            grad = p.grad
            if grad.is_sparse:
                raise RuntimeError("AdamW does not support sparse gradients")

            state = self.state[p]

            # Offload path: optimizer states live on CPU
            if self.offload_enabled and _should_offload_param(p, self.offload_min_param_elements):
                _adamw_offloaded_step(
                    p=p,
                    grad=grad,
                    state=state,
                    lr=lr,
                    beta1=beta1,
                    beta2=beta2,
                    eps=eps,
                    weight_decay=weight_decay,
                    amsgrad=amsgrad,
                    state_dtype=self.state_dtype,
                )
                continue

            # Standard in-VRAM path
            if len(state) == 0:
                state["step"] = 0
                state["exp_avg"] = torch.zeros_like(p, dtype=self.state_dtype)
                state["exp_avg_sq"] = torch.zeros_like(p, dtype=self.state_dtype)
                if amsgrad:
                    state["max_exp_avg_sq"] = torch.zeros_like(p, dtype=self.state_dtype)

            exp_avg, exp_avg_sq = state["exp_avg"], state["exp_avg_sq"]
            max_exp_avg_sq = state.get("max_exp_avg_sq", None)

            state["step"] += 1

            # Decay the first and second moment running average coefficient
            exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
            exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

            if amsgrad and max_exp_avg_sq is not None:
                torch.max(max_exp_avg_sq, exp_avg_sq, out=max_exp_avg_sq)
                denom = max_exp_avg_sq.sqrt().add_(eps * math.sqrt(1.0 - beta2 ** state["step"]))
            else:
                denom = exp_avg_sq.sqrt().add_(eps * math.sqrt(1.0 - beta2 ** state["step"]))

            bias_correction1 = 1.0 - beta1 ** state["step"]
            bias_correction2 = 1.0 - beta2 ** state["step"]
            step_size = lr * math.sqrt(bias_correction2) / bias_correction1

            # Apply decoupled weight decay
            if weight_decay != 0:
                p.mul_(1 - lr * weight_decay)

            p.addcdiv_(exp_avg, denom, value=-step_size)

    def zero_grad(self, set_to_none: bool = True):
        """Clear gradients of all optimized parameters."""
        for group in self.param_groups:
            for p in group["params"]:
                if p.grad is not None:
                    if set_to_none:
                        p.grad = None
                    else:
                        if p.grad.grad_fn is not None:
                            p.grad.detach_()
                        p.grad.zero_()

    def state_dict(self):
        """Return optimizer state as a dict."""
        return super().state_dict()

    def load_state_dict(self, state_dict):
        """Load optimizer state from a dict."""
        super().load_state_dict(state_dict)

    def __repr__(self):
        muon_groups = sum(1 for g in self.param_groups if g.get("optimizer_type") == "muon")
        adamw_groups = sum(1 for g in self.param_groups if g.get("optimizer_type") == "adamw")
        return (
            f"{self.__class__.__name__}("
            f"muon_groups={muon_groups}, "
            f"adamw_groups={adamw_groups}, "
            f"momentum={self.momentum}, "
            f"newton_schulz_steps={self.newton_schulz_steps}, "
            f"nesterov={self.nesterov})"
        )


def is_muon_param(param_name: str, param: torch.Tensor) -> bool:
    """
    Determine if a parameter should use Muon optimization.

    Muon applies to 2D weight matrices of hidden layers:
    - Attention projections: linear_q, linear_kv, attn_output
    - MLP projections: up_proj, down_proj

    Does NOT apply to:
    - Embeddings (word_embeddings, position_embedding)
    - Output layers (output_layer)
    - Biases (1D)
    - LayerNorm/RMSNorm parameters

    Args:
        param_name: Full parameter name in the model
        param: Parameter tensor

    Returns:
        True if parameter should use Muon, False otherwise
    """
    # Basic filters: 2D weight matrix only
    if param.dim() != 2 or not param_name.endswith(".weight"):
        return False

    # Exclude non-hidden-layer weights
    exclude_patterns = [
        "embedding",
        "output_layer",
        "lm_head",
        "position_embedding",
        "pos_embedding",
    ]
    if any(pat in param_name for pat in exclude_patterns):
        return False

    # Include attention and MLP weights.
    # linear_q/linear_kv/attn_output are direct children of TransformerLayer
    # (self_attention is a weightless compute module), so patterns must not
    # assume a "self_attention." or "attention." prefix.
    muon_patterns = [
        "linear_q.weight",
        "linear_kv.weight",
        "attn_output.weight",
        "mlp.up_proj.weight",
        "mlp.down_proj.weight",
    ]

    return any(pattern in param_name for pattern in muon_patterns)
