# Copyright (c) 2025-2026 Jaegeun Han
#
# SPDX-License-Identifier: Apache-2.0

import math

import torch
from torch import nn
from torch.nn import functional as F


class NewGELU(nn.Module):
    """GELU approximation used by GPT-2 in HuggingFace.

    This is the "gelu_new" activation from HuggingFace transformers:
    0.5 * x * (1.0 + tanh(sqrt(2.0 / pi) * (x + 0.044715 * x^3)))
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return (
            0.5
            * x
            * (1.0 + torch.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * torch.pow(x, 3.0))))
        )


class GLUActivation(nn.Module):
    """GLU Activation."""

    def __init__(self, input_dim: int, variant="glu"):
        super().__init__()
        self.variant = variant.lower()
        if self.variant in ["geglu", "siglu"]:
            self.linear = nn.Linear(input_dim, input_dim)
        if self.variant in ["glu", "geglu", "siglue"]:
            self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # x: [seq_len, batch_size, hidden_dim * 2]
        x_feature, x_gate = x.chunk(2, dim=-1)

        output = None
        if self.variant == "glu":
            output = x_feature * self.sigmoid(x_gate)
        elif self.variant == "geglu":
            output = self.linear(x_feature) * self.sigmoid(x_gate)
        elif self.variant == "siglu":
            output = x_feature * self.sigmoid(self.linear(x_gate))
        elif self.variant == "swiglu":
            output = F.silu(x_feature) * x_gate
        else:
            raise ValueError("Unknown GLU variant: {self.variant}")

        return output


def get_activation(activation_name, input_dim: int = None):
    """get activation function"""
    activation_layer = None
    if activation_name == "relu":
        activation_layer = nn.ReLU()
    elif activation_name == "gelu":
        activation_layer = nn.GELU()
    elif activation_name == "gelu_new":
        activation_layer = NewGELU()
    elif activation_name == "silu":
        activation_layer = nn.SiLU()
    elif "glu" in activation_name:
        assert input_dim is not None, "input_dim is required for GLU activation"
        activation_layer = GLUActivation(input_dim=input_dim, variant=activation_name)
    else:
        raise NotImplementedError
    return activation_layer
