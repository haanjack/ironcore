# Copyright (c) 2025-2026 Jaegeun Han
#
# SPDX-License-Identifier: Apache-2.0

from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any, Literal, Union, get_args, get_origin

import yaml


# pylint: disable=no-member
@dataclass
class BaseConfig:
    """configuration"""

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """update config"""
        for k, v in kwargs.items():
            if k not in self.__dataclass_fields__:
                raise KeyError(f"{k} is not defined in {self.__dataclass_fields__}")

            if isinstance(v, dict):
                # convert as config class type - only if it's a BaseConfig subclass
                field_type = self.__dataclass_fields__[k].type
                try:
                    if isinstance(field_type, type) and issubclass(field_type, BaseConfig):
                        current = getattr(self, k, None)
                        if isinstance(current, field_type):
                            # Merge onto what is already there, the way top-level
                            # groups behave. Building a fresh field_type(**v) from
                            # only the supplied keys reset every unmentioned
                            # sibling to its dataclass default — so an overlay
                            # tweaking one MoE field also silently set use_moe
                            # back to False.
                            v = current(**v)
                        else:
                            v = field_type(**v)
                except TypeError:
                    # field_type is not a class (could be string forward reference, Union, etc.)
                    pass
            setattr(self, k, v)
        return self

    @classmethod
    def from_dict(cls, kw_values):
        for k, v in kw_values.items():
            setattr(cls, k, v)
        return cls

    @classmethod
    def _type_checker(cls, var):  # noqa: PLR0911
        """check if arguments' data type is correct"""
        for field_name, field_type in cls.__annotations__.items():
            input_field_value = getattr(var, field_name)
            if input_field_value is None:
                continue

            origin = get_origin(field_type)
            args = get_args(field_type)

            if origin is list or (isinstance(field_type, type) and issubclass(field_type, list)):
                if not isinstance(input_field_value, list):
                    return False

                # If it's list[T], check element types
                if args:
                    inner_type = args[0]
                    # Handle Union types inside list, e.g., list[Union[int, str]]
                    if get_origin(inner_type) is Union:
                        union_args = get_args(inner_type)
                        if not all(isinstance(item, union_args) for item in input_field_value):
                            return False
                    elif isinstance(inner_type, type):
                        if not all(isinstance(item, inner_type) for item in input_field_value):
                            return False
                continue

            if origin is Union:
                union_args = get_args(field_type)
                matched = False
                for union_arg in union_args:
                    # Check for NoneType
                    if union_arg is type(None) and input_field_value is None:
                        matched = True
                        break
                    # Check for Literal types within Union
                    elif get_origin(union_arg) is Literal and input_field_value in get_args(
                        union_arg
                    ):
                        matched = True
                        break
                    # Check for regular types
                    elif isinstance(union_arg, type) and isinstance(input_field_value, union_arg):
                        matched = True
                        break
                if matched:
                    continue
                return False
            if get_origin(field_type) is Literal:
                if input_field_value in get_args(field_type):
                    continue
                return False
            # Check if field_type is a valid type for isinstance
            if not isinstance(field_type, type):
                # Skip type checking for non-type field_types (forward references, etc.)
                continue
            if isinstance(input_field_value, field_type):
                continue
            if hasattr(field_type, "_type_checker"):
                # nested check purpose
                if field_type._type_checker(field_type):
                    continue
                return False
            return False

        return True

    def to_yaml(self, filename: Union[str, Path]) -> None:
        def dataclass_to_dict(obj):
            if isinstance(obj, list):
                return [dataclass_to_dict(item) for item in obj]
            if hasattr(obj, "__dataclass_fields__"):
                return {k: dataclass_to_dict(v) for k, v in asdict(obj).items()}
            return obj

        data_dict = dataclass_to_dict(self)
        with open(filename, "w", encoding="utf-8") as file:
            yaml.dump(data_dict, file, default_flow_style=False)

    @classmethod
    def from_yaml(cls, filename: Union[str, Path]):
        def dict_to_dataclass(data, cls):
            if isinstance(data, dict):
                fieldtypes = {f.name: f.type for f in fields(cls)}
                return cls(**{k: dict_to_dataclass(v, fieldtypes[k]) for k, v in data.items()})
            if isinstance(data, list):
                return [dict_to_dataclass(item, cls.__args__[0]) for item in data]
            return data

        with open(filename, encoding="utf-8") as file:
            data = yaml.safe_load(file)
        return dict_to_dataclass(data, cls)
