# Copyright (c) 2025-2026 Jaegeun Han
#
# SPDX-License-Identifier: Apache-2.0
"""Common training utilities shared across training scripts."""

from typing import Union

import torch
import torch.distributed as dist

from ironcore.parallel import parallel_states


def _has_moe_layers(model: torch.nn.Module) -> bool:
    """Check if model has any MoE layers.

    Uses cached result if available.
    """
    # Use cached result if available
    if hasattr(model, "_has_moe_layers"):
        return model._has_moe_layers

    # Check for MoE layers
    for module in model.modules():
        if hasattr(module, "get_aux_loss") and callable(module.get_aux_loss):
            model._has_moe_layers = True
            return True

    model._has_moe_layers = False
    return False


def get_moe_aux_loss(model: torch.nn.Module) -> torch.Tensor | None:
    """Accumulate auxiliary losses from all MoE modules in the model.

    Iterates through all modules and collects get_aux_loss() from MoE layers.

    Args:
        model: The model potentially containing MoE layers

    Returns:
        Sum of all auxiliary losses, or None if no MoE layers
    """
    # Early exit for non-MoE models
    if not _has_moe_layers(model):
        return None

    aux_losses = []

    for module in model.modules():
        if hasattr(module, "get_aux_loss") and callable(module.get_aux_loss):
            loss = module.get_aux_loss()
            if loss is not None:
                aux_losses.append(loss)

    if aux_losses:
        return sum(aux_losses)

    return None


def clear_moe_aux_loss(model: torch.nn.Module) -> None:
    """Clear stored auxiliary losses from all MoE modules.

    Should be called after backward pass to reset for next iteration.

    Args:
        model: The model potentially containing MoE layers
    """
    # Early exit for non-MoE models
    if not _has_moe_layers(model):
        return

    for module in model.modules():
        if hasattr(module, "clear_aux_loss") and callable(module.clear_aux_loss):
            module.clear_aux_loss()


def loss_func_sft(
    output_tensor: torch.Tensor, loss_mask: torch.Tensor, sample_ids: torch.Tensor | None = None
) -> torch.Tensor:
    """Per-sample loss averaging for SFT.

    Each sample contributes equally regardless of token count.
    This prevents longer sequences from dominating the loss.

    Args:
        output_tensor: [batch, seq_len] per-token losses
        loss_mask: [batch, seq_len] valid token mask (1=count, 0=ignore)

    Returns:
        Scalar loss (mean of per-sample losses)
    """
    token_losses = output_tensor.float()
    loss_mask = loss_mask.float()

    if sample_ids is None:
        sample_token_sum = (token_losses * loss_mask).sum(dim=1)
        counts = loss_mask.sum(dim=1)
    else:
        # IDs belong to original documents, independently of packed row count.
        ids = sample_ids.to(output_tensor.device).reshape(-1)
        valid = (ids >= 0) & loss_mask.reshape(-1).bool()
        # The upper bound avoids GPU->CPU max().item() and dynamic allocation.
        sample_token_sum = token_losses.new_zeros(ids.numel())
        counts = token_losses.new_zeros(ids.numel())
        safe_ids = ids.clamp(min=0)
        sample_token_sum.scatter_add_(0, safe_ids, (token_losses * loss_mask).reshape(-1) * valid)
        counts.scatter_add_(0, safe_ids, valid.to(token_losses.dtype))
    active = counts > 0
    return ((sample_token_sum / counts.clamp(min=1)) * active).sum() / active.sum().clamp(min=1)


def batch_objective_count(batch, task):
    """Denominator of the main objective, computed before forward/backward."""
    if task == "dpo":
        return batch["chosen_input_ids"].size(0)
    mask = batch["labels"] != -100
    if task == "sft":
        if "loss_sample_ids" in batch:
            ids = batch["loss_sample_ids"][mask]
            return int(ids[ids >= 0].unique().numel())
        return int(mask.any(dim=1).sum())
    return int(mask.sum())


def compute_token_accuracy(
    logits: torch.Tensor,
    labels: torch.Tensor,
    loss_mask: torch.Tensor,
    *,
    logits_are_parallel: bool = True,
) -> float:
    """Compute next-token prediction accuracy on valid tokens.

    Args:
        logits: [batch, seq_len, vocab_size] model output logits
        labels: [batch, seq_len] ground truth token IDs
        loss_mask: [batch, seq_len] mask for valid positions (1=count, 0=ignore)

    Returns:
        Accuracy as float (0.0 to 1.0)
    """
    if logits_are_parallel and parallel_states.get_tensor_model_parallel_world_size() > 1:
        # TP mode: logits are sharded along vocab dimension [b, s, vocab/tp_size]

        # 1. Get local max and indices
        local_max_values, local_indices = torch.max(logits, dim=-1)  # [b, s]

        # 2. Adjust local indices to global vocab indices
        rank = parallel_states.get_tensor_model_parallel_rank()
        partition_vocab_size = logits.size(-1)
        start_idx = rank * partition_vocab_size
        global_indices = local_indices + start_idx

        # 3. Gather max values and indices from all ranks
        # We need to find which rank has the true global max
        tp_group = parallel_states.get_tensor_model_parallel_group()
        world_size = parallel_states.get_tensor_model_parallel_world_size()

        # List to gather into
        gathered_max_values = [torch.zeros_like(local_max_values) for _ in range(world_size)]
        gathered_indices = [torch.zeros_like(global_indices) for _ in range(world_size)]

        dist.all_gather(gathered_max_values, local_max_values, group=tp_group)
        dist.all_gather(gathered_indices, global_indices, group=tp_group)

        # Stack: [world_size, b, s]
        all_max_values = torch.stack(gathered_max_values)
        all_indices = torch.stack(gathered_indices)

        # 4. Find max across ranks
        # [b, s] indices of the rank that has the max value
        max_rank_indices = torch.argmax(all_max_values, dim=0)

        # 5. Select the corresponding global token index
        # We use gather to select from the specific rank index for each position
        # all_indices: [world_size, b, s] -> gather -> [1, b, s]
        predictions = torch.gather(all_indices, dim=0, index=max_rank_indices.unsqueeze(0)).squeeze(
            0
        )

    else:
        # Standard mode
        predictions = logits.argmax(dim=-1)  # [batch, seq_len]

    correct = (predictions == labels) & (loss_mask > 0)

    total_valid = loss_mask.sum()
    if total_valid == 0:
        return 0.0

    return (correct.sum() / total_valid).item()


def get_loss_func(task_type: str):
    """Get appropriate loss function based on task type.

    Args:
        task_type: Training task type ('pretrain', 'sft', 'dpo')

    Returns:
        Loss function callable
    """
    if task_type == "sft":
        return loss_func_sft
    # pretrain and dpo use per-token loss
    return loss_func


def get_batch(
    data_iterator,
) -> Union[torch.Tensor, torch.Tensor]:
    """Get batch from data iterator."""
    if data_iterator is not None:
        batch = next(data_iterator)
    else:
        batch = None

    # IronCore dataloader returns dict with 'input_ids' and 'labels'
    input_ids = batch["input_ids"]
    labels = batch["labels"]

    return input_ids, labels


# Module-level slot for the most recent MoE aux loss so trainers can log it
# as a metric after forward_step returns. (Fable issue #78.)
_last_moe_aux_loss: float = 0.0


def get_last_moe_aux_loss() -> float:
    """Return the aux loss from the most recent forward_step call, or 0.0."""
    return _last_moe_aux_loss


def forward_step(model, data_iterator) -> torch.Tensor:
    """Forward step with MoE auxiliary loss accumulation.

    Computes the language model loss and adds any MoE auxiliary losses.
    Clears aux loss after accumulation to prevent memory leaks.
    For non-MoE models, this is essentially a no-op overhead.
    """
    global _last_moe_aux_loss
    batch = next(data_iterator)
    model_kwargs = {
        key: batch[key]
        for key in ("position_ids", "attention_mask", "loss_sample_ids")
        if key in batch
    }
    loss = model(batch["input_ids"], batch["labels"], **model_kwargs)

    # Add MoE auxiliary loss if present (no-op for non-MoE models)
    aux_loss = get_moe_aux_loss(model)
    if aux_loss is not None:
        loss = loss + aux_loss
        _last_moe_aux_loss = float(aux_loss.detach().item())
        # Clear aux loss after accumulation to prevent memory leak
        clear_moe_aux_loss(model)
    else:
        _last_moe_aux_loss = 0.0

    return loss


def loss_func(output_tensor: torch.Tensor, loss_mask: torch.Tensor) -> torch.Tensor:
    """Loss function - computes mean over all valid tokens (nanoGPT style)."""
    token_losses = output_tensor.float()
    loss_mask = loss_mask.float()

    # Average over ALL valid tokens across the entire batch
    # This matches nanoGPT's F.cross_entropy behavior
    loss = torch.sum(token_losses * loss_mask) / torch.sum(loss_mask).clamp(min=1)

    return loss
