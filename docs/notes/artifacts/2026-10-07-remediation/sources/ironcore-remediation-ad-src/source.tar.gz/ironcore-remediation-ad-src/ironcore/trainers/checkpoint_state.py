# Copyright (c) 2025-2026 Jaegeun Han
# SPDX-License-Identifier: Apache-2.0
"""Rank-local trainer state accompanying native model checkpoints."""

import os
from pathlib import Path

import torch
from torch import distributed as dist

from ironcore.parallel import parallel_states
from ironcore.parallel.random import (
    restore_tensor_parallel_rng_tracker,
    snapshot_tensor_parallel_rng_tracker,
)


def _path(trainer, step):
    rank = dist.get_rank() if dist.is_initialized() else 0
    return Path(trainer.config.trainer.model_path) / f"step_{step}" / f"trainer_rank{rank}.pt"


def save_trainer_state(trainer, step):
    """Preserve frozen references, AMP scale and each worker's RNG streams."""
    if trainer.config.operation.no_save or not trainer.config.trainer.model_path:
        return
    reference = getattr(trainer, "reference_model", None)
    state = {
        "task": trainer.config.data.task_type,
        "world_size": dist.get_world_size() if dist.is_initialized() else 1,
        "tp_size": trainer.config.trainer.tensor_model_parallel_size,
        "scaler": trainer.scaler.state_dict(),
        "torch_cpu": torch.get_rng_state(),
        "torch_cuda": torch.cuda.get_rng_state() if torch.cuda.is_available() else None,
        "tp_rng": [
            {"key": list(key), "state": value.cpu()}
            for key, value in snapshot_tensor_parallel_rng_tracker().items()
        ],
        "reference": reference.state_dict() if reference is not None else None,
    }
    path = _path(trainer, step)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    with temporary.open("wb") as handle:
        torch.save(state, handle)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)
    if dist.is_initialized():
        dist.barrier()


def load_trainer_state(trainer, step):
    """Restore state after the policy and reference models have been created."""
    if step <= 0:
        return
    path = _path(trainer, step)
    if not path.exists():
        trainer.logger.warning(
            "Checkpoint has no rank-local trainer state; reference/AMP/RNG resume "
            "equivalence is unavailable (legacy checkpoint or changed topology)."
        )
        return
    state = torch.load(path, map_location="cpu", weights_only=True)
    if state["task"] != trainer.config.data.task_type:
        # Loading an SFT checkpoint to initialize alignment is a new task.
        return
    world_size = dist.get_world_size() if dist.is_initialized() else 1
    if (state["world_size"], state["tp_size"]) != (
        world_size,
        trainer.config.trainer.tensor_model_parallel_size,
    ):
        raise ValueError("Trainer state resume requires the original DP/TP topology")
    if trainer.config.optim.load_checkpoint_optim_state:
        trainer.scaler.load_state_dict(state["scaler"])
    reference = getattr(trainer, "reference_model", None)
    if reference is not None and state["reference"] is not None:
        reference.load_state_dict(state["reference"], strict=True)
    torch.set_rng_state(state["torch_cpu"])
    if torch.cuda.is_available() and state["torch_cuda"] is not None:
        torch.cuda.set_rng_state(state["torch_cuda"])
    restore_tensor_parallel_rng_tracker(
        {tuple(entry["key"]): entry["state"] for entry in state["tp_rng"]},
    )
    # Detect accidental restoration into a different initialized parallel mode.
    assert parallel_states.get_tensor_model_parallel_world_size() == state["tp_size"]
