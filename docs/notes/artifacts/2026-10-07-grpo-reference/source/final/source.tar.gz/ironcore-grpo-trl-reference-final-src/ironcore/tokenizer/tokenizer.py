# Copyright (c) 2025-2026 Jaegeun Han
#
# SPDX-License-Identifier: Apache-2.0

from pathlib import Path
from typing import Union

from transformers import AutoTokenizer, GPT2Tokenizer

from ironcore.config import MainConfig
from ironcore.utils import load_yaml_config

try:
    import tiktoken
except ImportError:
    raise ImportError("tiktoken is not installed.")


class Tokenizer:
    def __init__(
        self,
        tokenizer,
        vocab_name_or_path: Union[str, Path],
        vocab_padding_unit: int = 128,
        special_tokens_config: dict[str, str] | None = None,
    ):
        self._tokenizer = tokenizer
        self.vocab_name_or_path = vocab_name_or_path

        if special_tokens_config:
            for token_name, token_value in special_tokens_config.items():
                setattr(self._tokenizer, token_name, token_value)

        # eos token
        self._eos_token = (
            getattr(self._tokenizer, "eot_token", None)
            or getattr(self._tokenizer, "eod_token", None)
            or getattr(self._tokenizer, "eos_token", None)
        )
        assert self._eos_token is not None, (
            "eos_token not found in the tokenizer. Please check special_tokens_config or tokenizer settings."
        )

        # pad token
        if self._tokenizer.pad_token is None:
            self._tokenizer.pad_token = self._tokenizer.eos_token
            self._tokenizer.pad_token_id = self._tokenizer.eos_token_id

        # vocab_size
        self._vocab_size = getattr(
            self._tokenizer, "vocab_size", getattr(self._tokenizer, "n_vocab", None)
        )
        assert self._vocab_size is not None, "Could not find vocab_size property in tokenizer"
        # HF vocab_size excludes added tokens; attribute names are not tokens.
        # Count the actual token IDs once, rather than double counting specials.
        if hasattr(self._tokenizer, "get_vocab"):
            self._vocab_size = max(self._tokenizer.get_vocab().values()) + 1
        vocab_size = self._vocab_size
        # padding to the nearest multiple of vocab_padding_unit
        self._padded_vocab_size = (
            (vocab_size + vocab_padding_unit - 1) // vocab_padding_unit * vocab_padding_unit
        )

    @property
    def eos_token(self):
        """eos token"""
        return self._eos_token

    @eos_token.setter
    def eos_token(self, value):
        self._eos_token = value
        if hasattr(self._tokenizer, "eos_token"):
            self._tokenizer.eos_token = value

    @property
    def eos_token_id(self):
        return self._tokenizer.eos_token_id

    @property
    def eod_token_id(self):
        if hasattr(self._tokenizer, "eod_token_id"):
            return self._tokenizer.eod_token_id
        return self.eos_token_id

    @property
    def pad_token(self):
        return self._tokenizer.pad_token

    @property
    def pad_token_id(self):
        return self._tokenizer.pad_token_id

    @property
    def vocab_size(self):
        return self._vocab_size

    @property
    def padded_vocab_size(self):
        return self._padded_vocab_size

    def encode(self, *args, **kwargs):
        return self._tokenizer(*args, **kwargs)

    def decode(self, token_ids, skip_special_tokens: bool = False, **kwargs):
        """Decode a sequence of token IDs to a string.

        Args:
            token_ids: List of token IDs or 1D tensor
            skip_special_tokens: Whether to remove special tokens from output
            **kwargs: Additional arguments passed to underlying tokenizer

        Returns:
            Decoded string
        """
        try:
            return self._tokenizer.decode(
                token_ids, skip_special_tokens=skip_special_tokens, **kwargs
            )
        except Exception as e:
            print(f"Error occured during decoding: {e}")
            return ""

    def batch_decode(self, sequences, skip_special_tokens: bool = False, **kwargs):
        """Decode a batch of token sequences to strings.

        Args:
            sequences: List of token ID sequences or 2D tensor
            skip_special_tokens: Whether to remove special tokens from output
            **kwargs: Additional arguments passed to underlying tokenizer

        Returns:
            List of decoded strings
        """
        return self._tokenizer.batch_decode(
            sequences, skip_special_tokens=skip_special_tokens, **kwargs
        )

    def apply_chat_template(self, messages, **kwargs):
        """Apply chat template to messages.

        Delegates to the underlying HuggingFace tokenizer's apply_chat_template.

        Args:
            messages: List of message dicts with 'role' and 'content'
            **kwargs: Additional arguments (add_generation_prompt, return_tensors, etc.)

        Returns:
            Token IDs or text depending on return_tensors argument
        """
        if hasattr(self._tokenizer, "apply_chat_template"):
            return self._tokenizer.apply_chat_template(messages, **kwargs)
        raise NotImplementedError(
            f"Tokenizer {type(self._tokenizer).__name__} does not support apply_chat_template"
        )

    def __call__(self, *args, **kwargs):
        return self.encode(*args, **kwargs)

    def __str__(self):
        return (
            f"Tokenizer type: {self.__class__.__name__}\n"
            f"Vocab path: {self.vocab_name_or_path}\n"
            f"Vocab size: {self._vocab_size}\n"
            f"Padded vocab size: {self._padded_vocab_size}\n"
            f"EOS token: {self._eos_token}\n"
        )


class BbpeTokenizer(Tokenizer):
    def __init__(
        self,
        vocab_name_or_path: Union[str, Path],
        merge_file_path: Union[str, Path] | None = None,
        vocab_padding_unit: int = 128,
        special_tokens_config: dict[str, str] | None = None,
    ):

        if merge_file_path:
            tokenizer = tiktoken.get_bpe_tokenizer(vocab_name_or_path, merge_file_path)
        else:
            tokenizer = GPT2Tokenizer.from_pretrained(vocab_name_or_path)

        super().__init__(
            tokenizer,
            vocab_name_or_path,
            vocab_padding_unit,
            special_tokens_config,
        )


class SentencePieceTokenizer(Tokenizer):
    def __init__(
        self,
        vocab_name_or_path: Union[str, Path],
        vocab_padding_unit: int = 128,
        special_tokens_config: dict[str, str] | None = None,
    ):
        tokenizer = AutoTokenizer.from_pretrained(vocab_name_or_path)

        super().__init__(
            tokenizer,
            vocab_name_or_path,
            vocab_padding_unit,
            special_tokens_config,
        )


def build_tokenizer(config: MainConfig) -> Tokenizer:
    """Initialize trainer's tokenizer"""

    tokenizer_type = config.model.tokenizer_type.lower()

    # load special tokens config if exists
    if config.trainer.special_tokens_config_path:
        special_tokens_config = load_yaml_config(config.trainer.special_tokens_config_path)
    else:
        special_tokens_config = None

    kwargs = {
        "vocab_name_or_path": (
            config.model.vocab_name_or_path
            if config.model.vocab_name_or_path
            else config.trainer.model_path
        ),
        "vocab_padding_unit": config.trainer.vocab_padding_unit,
        # The field is special_tokens_config_path; the old guard checked for an
        # attribute named special_tokens_config, which TrainerConfig has never had,
        # so this was always None and the YAML loaded just above was discarded.
        "special_tokens_config": special_tokens_config,
    }

    # tokenizer types
    bbpe_types = {"bbpe", "gpt2"}
    sentencepiece_tyeps = {"sentencepiece", "llama", "t5"}

    if tokenizer_type in bbpe_types or tokenizer_type in tiktoken.list_encoding_names():
        # Only BbpeTokenizer accepts merge_file_path, so it cannot go in the shared
        # kwargs above — which is why it was dropped entirely and the tiktoken BPE
        # branch of that constructor was unreachable from a config.
        return BbpeTokenizer(merge_file_path=config.model.merge_file_path, **kwargs)
    elif tokenizer_type in sentencepiece_tyeps:
        return SentencePieceTokenizer(**kwargs)
    else:
        raise NotImplementedError(f"Given tokenizer ({tokenizer_type}) is not implemented.")
